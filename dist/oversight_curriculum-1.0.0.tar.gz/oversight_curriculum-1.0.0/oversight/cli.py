import sys
from .__main__ import main


def cli_entry():
    """Entry point for the 'oversight' console script."""
    sys.exit(main()) 